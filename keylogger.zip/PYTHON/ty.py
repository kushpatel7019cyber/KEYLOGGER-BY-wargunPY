def reverse_words_order_and_swap_cases(string):
    reversed_string = ' '.join(reversed(string.split())).swapcase()
    return reversed_string

input_string = "aWESOME is cODING"
output_string = reverse_words_order_and_swap_cases(input_string)
print(output_string)
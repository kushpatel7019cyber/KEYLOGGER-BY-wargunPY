#OOPs methods():
# create student class that takes name and marks of 3 subjects as arguments in constructor.then create method to calc 
#the avg of those
"""class student:
    def __init__(self,name,marks):
        self.name = name
        self.marks = marks
    @staticmethod
    def hello():
        print("hello kanha")    
    def get_avg(self):
        sum = 0
        for val in self.marks:
            sum += val
        print("Hi",self.name, "your avg score is",sum/3)

s1 = student("Pavan",[98,92,89])
s1.get_avg()
# can modify name as well
s1.name = "Kanha"5

s1.get_avg()
s1.hello()"""

# static method --that dont use self parameter(works at class level)
 
"""def read_lines(N):
    if N <= 0:
        print("Value not in range")
    else:
        lines = []
        for _ in range(N):
            line = input("Enter a line: ")
            lines.append(line)
        return lines
"""
# Example usage:
"""try:
    N = int(input("Enter the number of lines: "))
    lines = read_lines(N)
    if lines:
        print("Lines entered:", lines)
except ValueError:
    print("Invalid input! Please enter a valid integer.")"""

# x = "abcdef"
# i = ""
# while i in x:
#     print(i, end=" ")


# true = False
# while True:
#     print(True)
#     break

# sum = 0
# values = [1,3,5,7]
# for number in values:
#     sum = sum + number
# print(sum)    
"""
def read_values_until_v():
    values = []
    v = input("Enter the initial value (V): ")
    value = input("Enter a value: ")

    while value != v:
        values.append(value)
        value = input("Enter a value: ")

    # Remove the first occurrence of V from the list
    if v in values:
        values.remove(v)

    return values

# Example usage:
result = read_values_until_v()
print("Values read until the initial value (V):", result)"""

"""a = []
for i in range(1,20):
    if i%2 == 0:
        a.append(i**2)
print(a)"""


# a = [i**2 for i in range(1,20) if i%2==0]
# print(a)
# round(4.576)
# print(round(4.5676,2))

# print(min(max(False,-3,-4),2,7))
"""
rcb_players = ["virat kohli","pavan mare","faf du","md siraj","yuzi chahal"]

print(list(map(lambda x :x.split()[1],rcb_players)))

l = [2,5,7,8,9,12,56]
from functools import reduce
max_n = lambda a,b: a if (a>b) else b
print(reduce(max_n,l))

m = [1,2,4,5,6,7,8,9,12,34,23,55,34,33,28]
print(list(filter(lambda x: x%2 ==0,l)))"""


# le = ["beach","car"]

# fun = list(map(lambda word:f"{word} is fun!",le))
# print(fun)

# ads = (lambda x:(x+3) * 5/2)(3)
# print(ads)

# import functools
# num = [1,2,3,4]
# print(functools.reduce(lambda x,y:x*y,num))

import timeit 
import numpy as np 
import random
#print("Pavan is my name","my age is 25")
#print(23+24)
# my name is pavan
#name = input("name : ")
#age = int(input("age : "))
#price = float(input("price : "))
#print("my name is",name,"and i am ",age,"years old")
# conditional statements:-
"""A = int(input("A : "))
G = input("M/F : ")

if(A==1 or A==2) and (G=="M"):
    print("fee is 100")
elif(A==3 or A==4 or G=="F"):
    print("fee is 200")    
elif(A==5 and G=="M"):
    print("fee is 300")
else:
    print("no fee")"""

"""marks=int(input("enter student marks : "))

if(marks>= 90):
    grade ="A"
elif(marks>=80 and marks<90):
    grade ="B"
elif(marks>=70 and marks<80):
    grade ="C"
else:
    grade="D"
print("student grade is",grade) """   

# list1 = [1,2,1]
# list2 = [1,2,3]

# list3= list1.copy()
# print(list3)
# if(list1==list3):
#     print("palindrome")
# else:
#     print("not palindrome")    

# movies = []
# movies.append(input("name of 1st movie :"))
# movies.append(input("name of 2nd movie :"))
# movies.append(input("name of 3rd movie :"))
# print(movies)


student = {
    "name" : "pavan mare",
    "subjects" : {
        "phy" : 97,
        "chem" : 98,
        "math" : 95
    }
 }
# print(student["subjects"]["math"])
# print(len(list(student.keys())))

# new_dict={"city":"pune"}
# student.update(new_dict)
# print(student)


# collection={1,2,2,4,"hello","world","world"}
# print(collection)
# print(type(collection))
# print(len(collection))

# collection= {"hello","reddy","data scientist"}
# print(collection.pop())
# print(collection.pop())

# set1 = {1,2,3}
# set2 = {2,3,4}

# print(set1.union(set2))
# print(set1.intersection(set2))
# n = int(input("enter number: "))
# i = 1
# while i<=10:
#     print(n*i)
#     i+=1
    
# print("Loop ended")

# nums = (1,4,9,16,25,36,49,64,81,90,100,49)
# x = 49
# i = 1
# while i <= 10:
#     if(i == 9):
#         i += 1
#         continue
#     print(i) 
#     i += 1
# print("end of the show")
# veggies = ["potato", "tomato", "cucumber"]

# for val in veggies:
#     print(val)
    
# str = "Pavanreddy"

# for char in str:
#     print(char)
# n = int(input("enter number n: "))
# for i in range(1,11):
#     print(n*i)

# n = 6
# fact = 1
# i = 1
# for i in range(1,n+1):
#     fact *= i
#     i += 1
# print("factorial of numbers", fact)  
"""
def calc_avg(a,b,c):
    sum = a + b + c
    avg = sum / 3
    print(avg)
    return avg


cities = ["Pune","Mumbai","delhi","hyd","Bengluru"]
heroes = ["ironman","captain america","thor","hulk"]

def print_len(list):
    print(len(list))
    return(len(list))



def show_list(list):
    for item in list:
        print(item , end = "  ")"""



# def calc_fact(n):
#     fact = 1
#     for i in range(1, n+1):
#         fact *= i
#     print(fact)

# calc_fact(5)

# def converter(usd_value):
#     inr_value = usd_value * 83
#     print(usd_value,"USD =",inr_value,"INR")
#     return usd_value


# def diff_odeven(a,b):
#     for i in range(a,b):
#         if(i%2 == 0):
#             print("EVEN - ",i)
#         else:
#             print("ODD - ",i)    
#         i += 1

# diff_odeven(2,16)

# def show(n):
#     if(n == 0):
#         return
#     print(n)
#     show(n-1)

# show(5)    
        
# def calc_sum(n):
#     if(n == 0):
#         return 0
#     return calc_sum(n-1) + n       
    
         

# sum = calc_sum(15)
# print(sum)
      
"""def print_list(list,idx=0)  :
    if(idx == len(list)):
        return
    print(list[idx])    
    print_list(list,idx+1)

fruits = ["mango","orange","pineapple","apple"]
print_list(fruits)"""


"""f = open("demo.txt","a")
data = f.write("\n which certainly is possible")
f.close()"""

# import os

# os.remove("untitled-1.py")

"""f = open("practice.txt", "r")
data = f.read()

new_data = data.replace("python","Java")
print(new_data)

with open("practice.txt","w") as f:
    f.write(new_data)"""
"""
def search_for_wrd():
    word = "learning"
    with open("practice.txt","r") as f:
        data = f.read()
        if data.find(word) != -1:
            print("Found")
        else:
            print("Not Found")"""
        
"""def chk_for_line():
    word = "learning"
    data = True
    line_no = 1
    with open("practice.txt","r") as f:
        while data:
            data = f.readline()  
            if(word in data):
                print(line_no) 
            line_no += 1 """       
"""def spot_word() :
    word = "chk"
    data = True
    line_no = 1
    with open("practice.txt","r") as f:
        while data:
            data = f.readline()
            if(word in data):
                print(line_no)
                return 
            line_no += 1
    return -1
print(spot_word())"""
"""
with open("practice.txt","r") as f:
    data = f.read()
    print(data)
count = 0
nums = data.split(",")
for val in nums:
    if (int(val) %2 == 0):
        count += 1

print(count)        
'"""
# creating a class:
"""class student:
    def __init__(self,fullname,marks) -> None:
        self.name = fullname
        self.marks = marks 
        print("something new is loading in database")
# creating a object
s1 = student("pavanreddy",97)
print(s1.name,s1.marks) 
s2 = student("kanha",98)
print(s2.name,s2.marks)"""



"""str = "castaway"


s = "undermined"
print(s[-1])
p = [1,2,3,None,(1,2,3,4,5),['welcome','to','python']]
#print(len(p))
p1 = p
print(p1)

s = "bikes"
print(s[-1])

e = [1,2,3,4,5,6,7]
print(e[2:])"""

"""a = [(2,4),(1,2),(3,9)]
a.sort()
print(a)


a,b,c = (1,2,3,4,5,6,7,8,9)[1::3]
print(c)"""

"""a = 5
b = -5
a,b = (b,a)[::-1]
print(a,b)"""



"""
etuple = ("orange",[10,20,30],(5,15,25))
print(etuple[1][1])"""
# p = {1:"A", 2:"B",3:"C"}
# q = {"str":"D",5:"E"}
# p.update(q)
# print(p)

"""a,b = 12,5
if a + b:
    print("True")
else:
    print("False")   """



""""x = 3
y = 5
z = x < 2 and y == 5 or y > 4

print(z)
int u = 25
print(u)"""

# class car :
#     def __init__(self,color,name):
#         self.color = "Black"
#         self.name = "G-wagon"
#     def welcome(self):
#         print("welcome car company",self.name)
    

# car1 = car("G-wagon","Black")
# car1.welcome()
# N = 0
# for i in range(0,9):
#     if N > 0:
#         print(i)
# else:
#     print("Not in range.")    


# N = int(input(5,1))
# lines = readlines()
# if lines:
#     print("Lines entered:", lines)
# else:
#     print("Invalid input! Please enter a valid integer.")



5
if 5 <= 0:
    print("Value not in range")
else:
    lines = []
    for _ in range(5):
        line = input("Enter a line: ", 24)
        lines.append(line)
        return lines
    





















